/*
Thanks to 
Thanks to 
Thanks to 
Thanks to 
*/

import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

global.owner = [
  ['6282387150688', './DJ_Z', true],
  ['6287739111928']
] // Nomor Owner

global.mods = ['6282387150688'] 
global.prems = ['6282387150688', '6287739111928']

// apikey
global.lann = 'oxooBggf'
// apikeylu di ganti menggunakan apikey yang di dapatkan di website https://api.betabotz.org. contohnya global.lann = 'nans' (contoh). cara mendapatkan apikey. masuk website > scroll ke bawah dan cari harga yang kamu mau ada juga yang free dan tekan > otomatis akan di arahkan untuk registrasi, isi data diri email dll. > kalo sudah klik profil dan di situ akan muncul apikey mu. terima kasih.

global.APIKeys = { // APIKey Here
  // 'https://website': 'apikey'
  'https://api-fgmods.ddns.net': 'mhdAnan',
  'https://api.betabotz.org': 'oxooBggf'
}

global.APIs = { // API Prefix
  // name: 'https://website'
  nrtm: 'https://fg-nrtm.ddns.net',
  fgmods: 'https://api-fgmods.ddns.net',
  lann: 'https://api.betabotz.eu.org'
}

// Watermark
global.nama = 'ZAEL JANDRI' // nama owner
global.nomor = '6282387150688' // nomor owner
global.nans = './DJ_ZBotz' // nama bot 
global.thumb = 'https://ebwebhosting.com/bot/img/Hacked%20By%20.DJ_Z.jpg' // thumbnail bot ( foto menu )
global.dygp = 'https://chat.whatsapp.com/KJlZEGkCnd49Do7OaSu92m' // link group yang ada di menu

// Sticker wm
global.packname = './DJ_Zbotz' 
global.author = './DJ_Z' 
global.fgig = 'https://www.instagram.com/noaccount' // bebas tapi jangan kosong 
global.fgsc = 'https://github.com/djzbelike' // bebas tapi jangan kosong
global.fgyt = 'https://ebwebhosting.com/bot' // bebas tapi jangan kosong
global.fgpyp = 'https://ebwebhosting.com/bot' // bebas tapi jangan kosong
global.fglog = 'https://ebwebhosting.com/bot/img/Hacked%20By%20.DJ_Z.jpg'

// Other
global.dana = '6282387150688'
global.qris = 'https://ebwebhosting.com/bot/img/qris.jpg'
global.web = 'https://ebwebhosting.com/bot'
global.email = 'seoganz07@gmail.com'
global.lastm = 'ꜱɪᴍᴘʟᴇ ʙᴏᴛ ᴡʜᴀᴛꜱᴀᴘᴘ ʙʏ ./𝙳𝙹_𝚉'

global.wait = 'Tunggu sebentar....'
global.rwait = '⌛'
global.dmoji = '🤭'
global.done = '✅'
global.error = '❌' 
global.xmoji = '🔥' 

global.multiplier = 69 
global.maxwarn = '2' // Peringatan maksimum

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})